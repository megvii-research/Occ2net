from src.config.default import _CN as cfg

cfg.LOFTR.ROTATE_FEATURE = False
# cfg.LOFTR.COARSE.TEMP_BUG_FIX = False
cfg.LOFTR.MATCH_COARSE.MATCH_TYPE = "dual_softmax"
cfg.LOFTR.SPVS_MASK = "valid"  # options: ["loop_back", "valid", "nonocc"]

cfg.LOFTR.MATCH_COARSE.SPARSE_SPVS = False
cfg.LOFTR.RESNETFPN.INITIAL_DIM = 128
cfg.LOFTR.RESNETFPN.BLOCK_DIMS = [128, 196, 256]
cfg.LOFTR.COARSE.D_MODEL = 256
cfg.LOFTR.COARSE.BLOCK_TYPE = "quadtree"
cfg.LOFTR.COARSE.ATTN_TYPE = "B"
cfg.LOFTR.COARSE.TOPKS = [32, 16, 16]
cfg.LOFTR.FINE.D_MODEL = 128

cfg.TRAINER.MSLR_MILESTONES = [3, 6, 9, 12, 17, 20, 23, 26, 29]
