## code, results
'code' file including our code.



## paper
Image matching is a fundamental and critical task in various visual applications, such as Simultaneous Localization and Mapping (SLAM) and image retrieval, which
require accurate pose estimation. However, most existing methods ignore the occlusion relations between objects
caused by camera motion and scene structure. In this paper,we propose Occ2Net, a novel image matching method that
models occlusion relations using 3D occupancy and infersmatching points in occluded regions. Thanks to the inductive bias encoded in the Occupancy Estimation (OE) module, it greatly simplifies bootstrapping a multi-view consistent 3D representation that can then integrate information from multiple views. Together with an Occlusion-Aware (OA) module, it incorporates attention layers and rotation alignment to enable matching between occluded and visible points. We evaluate our method on both real-world and simulated datasets and demonstrate its superior performance over state-of-the-art methods on several metrics, especially in occlusion scenarios.

## Training
The results can be reproduced when training with 8 gpus. Please run the following commands.
```
sh scripts/reproduce_train/indoor_quadtree_ds.sh
```
The parameter top K can be reduced for speeding up. The performance won't drop too much. Please set this parameter in cfg.LOFTR.COARSE.TOPKS.

## Testing
```
sh scripts/reproduce_test/indoor_ds_quadtree.sh
```
